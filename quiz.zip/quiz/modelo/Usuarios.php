<?php

require_once __DIR__ . "/../database/Pdeo.php";

class Usuarios
{

    private int $idUsuario;
    private string $nombre;
    private string $email;
    private string $contrasena;
    private string $fechaRegistro;
    public static function getAllUsuarios(): array
    {
        return Pdeo::getConnection()
            ->query("SELECT * FROM usuarios ;")
            ->getAll("Usuarios");
    }

    public static function verificarUsuario($nombreUsu, $contrasena)
    {
        try {
            // Obtener la conexión a la base de datos
            $conexion = Pdeo::getConnection();

            // Construir la consulta para obtener el usuario por nombre
            $sql = "SELECT * FROM usuarios WHERE nombre = '$nombreUsu'";

            // Ejecutar la consulta
            $conexion->query($sql);

            // Obtener el usuario por nombre
            $usuario = $conexion->getRow("Usuarios");

            // Verificar si se encontró un usuario y si la contraseña coincide
            if ($usuario && ($contrasena == $usuario->contrasena)) {
                // El usuario y la contraseña son correctos, redirigir a home.php
                header("Location: ./vistas/home.php.twig");
                exit;
            } else {
                // El usuario y/o contraseña son incorrectos, redirigir a login con mensaje de error
                echo "usuario y/o contraseña incorrecto";
            }
        } catch (Exception $e) {
            // Manejar la excepción (por ejemplo, mostrar un mensaje de error genérico)
            echo "Error en la conexión: " . $e->getMessage();
        }
    }


    public static function registrarUsuario($nombreUsu, $email, $contrasena, $contrasenaRep)
    {
        try {
    
            // Obtener la conexión a la base de datos
            $conexion = Pdeo::getConnection();
    
            // Consulta para verificar que no se repiten usuarios o contraseñas
            $sqlConsulta = "SELECT * FROM usuarios WHERE nombre = '$nombreUsu' OR email = '$email'";
    
            // Ejecutar la consulta
            $resultConsulta = $conexion->query($sqlConsulta);
    
            // Verificar si hay resultados
            if ($resultConsulta && $resultConsulta->rowCount() > 0) {
                echo "Usuario y/o email ya existentes";
            }
    
            // Consulta para insertar el nuevo usuario en la base de datos
            $sqlInsercion = "INSERT INTO usuarios (nombre, email, contrasena) VALUES ('$nombreUsu', '$email', '$contrasena')";
    
            // Ejecutar la consulta de inserción
            $conexion->query($sqlInsercion);
    
            echo "Usuario registrado exitosamente";
    
        } catch (Exception $e) {
            // Manejar la excepción según sea necesario
            echo "Error al registrar el usuario: " . $e->getMessage();
        }
    } 
}
