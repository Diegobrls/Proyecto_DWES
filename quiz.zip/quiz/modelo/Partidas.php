<?php

require_once __DIR__ . "/../database/Pdeo.php" ;

    class Partidas {

        public int $idPartida ;
        public int $idUsuario ;
        public int $puntuacion ;
        public string $fechaInicio ;
        
        public static function getAllPartidas(): array {
            return Pdeo::getConnection()
                         ->query("SELECT * FROM partidas;")
                         ->getAll("partidas") ;            
         }

    }