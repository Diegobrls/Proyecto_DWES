<?php

require_once __DIR__ . "/../database/Pdeo.php" ;

    class Ranking {

        public int $idUsuario ;
        public int $totalJugador ;
        public static function getAllRanking(): array {
            return Pdeo::getConnection()
                         ->query("SELECT * FROM ranking ;")
                         ->getAll("ranking") ;            
         }

    }