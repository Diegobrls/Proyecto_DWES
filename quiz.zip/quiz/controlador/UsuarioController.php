<?php

require_once "Controller.php";
include_once __DIR__ . "/../modelo/Usuarios.php";
// require_once "librerias/libreria.php" ;

class UsuarioController extends Controller
{

    /**
     * Muestra el formulario de login
     * @return
     */
    public function showLogin()
    {

        // Generamos el token para protección CSRF
        $token = md5(uniqid(mt_rand()));

        // Guardamos el token en la sesión
        $_SESSION["_csrf"] = $token;

        // Cargamos la vista de login y le pasamos el token
        $this->render("/login.php.twig");
        // $this->render("/login.php.twig", ["token" => $token]) ;
    }

    public function procesarLogin()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Obtener datos del formulario
            $nombreUsu = $_POST["nombreUsu"];
            $contrasena = $_POST["contrasena"];
            Usuarios::verificarUsuario($nombreUsu, $contrasena);
        }
    }

    public function procesarRegistro()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Obtener datos del formulario
            $nombre = $_POST["nombreUsu"];
            $email = $_POST["email"];
            $contrasena = $_POST["contrasena"];
            $contrasenaRep = $_POST["contrasenaRep"];

            if ($contrasena != $contrasenaRep) {
                echo "Las contraseñas no coinciden";
            } else {
                // Llamar al método registrarUsuario del modelo
                Usuarios::registrarUsuario($nombre, $email, $contrasena, $contrasenaRep);
            }
        }
    }
}