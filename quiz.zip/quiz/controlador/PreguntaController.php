<?php
require_once __DIR__ . "/../modelo/Preguntas.php";
require_once "Controller.php";

class PreguntaController extends Controller
{
    // ...

    public function showJuego()
    {
        // Obtén el ID de la pregunta desde la solicitud o desde alguna lógica de juego
        $idPregunta = $_GET['idPregunta'] ?? 1;

        // Solicita al modelo la pregunta con el ID actual
        $pregunta = Preguntas::getPreguntaById($idPregunta);

        // Muestra la información en la vista
        $this->render("/jugar.php.twig", ["datos" => $pregunta]);
    }
}
