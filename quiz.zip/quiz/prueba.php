<?php
 require_once "./modelo/Preguntas.php" ;
 require_once "./modelo/Usuarios.php" ;
 require_once "./modelo/Ranking.php" ;
 require_once "./modelo/PreguntasPartida.php" ;
 require_once "./modelo/Partidas.php" ;

 echo "<pre>" ;
 print_r(Preguntas::getAllPreguntas()) ;
 echo "</pre>" ;

 echo "<pre>" ;
 print_r(Usuarios::getAllUsuarios()) ;
 echo "</pre>" ;

 echo "<pre>" ;
 print_r(Ranking::getAllRanking()) ;
 echo "</pre>" ;

 echo "<pre>" ;
 print_r(PreguntasPartida::getAllPreguntasPartida()) ;
 echo "</pre>" ;

 echo "<pre>" ;
 print_r(Partidas::getAllPartidas()) ;
 echo "</pre>" ;

?>